void main(List<String> arguments) {
  var nomes = <String>['Ana', 'Luciana', 'Edson', 'Pedro', 'Tina'];
  print(nomes);

  nomes.removeWhere((String nome) => nome == 'Ana');
  print(nomes);

  //Remover mais de um item diferente
  nomes.removeWhere((String n) => n == 'Pedro' || n == 'Tina');
  print(nomes);
}
